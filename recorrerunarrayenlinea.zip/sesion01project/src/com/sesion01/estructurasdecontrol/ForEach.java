package com.sesion01.estructurasdecontrol;

public class ForEach {

    public static void main(String[] args) {

        String[] nombres = {"Pepe", "Juanito", "Jose"};

        for(String nombre : nombres){

        }
        int suma = 0;
        int[] numeros = {1, 2, 3, 4, 5};
        for(int numero : numeros){
            System.out.println(numero);
            suma += numero;
            System.out.println(suma);
        }

    }
}
