package com.sesion01.estructurasdecontrol;

public class funciondeconcatenacion {

    public static void main(String[] args) {
        String[] nombres = {"Me", "cago", "en", "Dios"};
        String nombreguardado;
        int i = 0;

        for (i = 0; i < nombres.length; i++ ) {
            System.out.println(nombres[0] + " " + nombres[1] + " " + nombres[2] + " " + nombres[3]);
            break;
        }


    }
}
