package com.sesion01.estructurasdecontrol;

public class repeticion {

    public static void main(String[] args) {

        for(int i = 0; i < 10; i++){
            System.out.println("El valor de i es: " + i);
        }
        //array
        String[] nombres = {"Pepe", "Juanito", "Jose"};
        for(int i = 0; i < nombres.length; i++){
            System.out.println(nombres[i ]);
        }

    }
}
