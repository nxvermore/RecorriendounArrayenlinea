package com.sesion01.estructurasdecontrol;

public class condicionales {

    public static void main(String[] args) {


        //clase if
        int edad = 23;

        boolean esMayor = edad >= 18; //false

        if(esMayor){
            System.out.println("Es mayor de edad");
        }


        //clase if else
        if(edad >= 18){
            System.out.println("Es mayor de edad");

        } else {

            System.out.println("Es menor de edad");
        }
    }
}
