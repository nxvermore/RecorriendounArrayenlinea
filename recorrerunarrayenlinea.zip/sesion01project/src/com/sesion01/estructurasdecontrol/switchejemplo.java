package com.sesion01.estructurasdecontrol;

public class switchejemplo {

    public static void main(String[] args) {

        String dia = "Martes";

        switch(dia){
            case "Lunes":
                System.out.println("Si es lunes");
                break; //rompe el flujo de ejecución si es correcto
            case "Martes":
                System.out.println("Si es martes");
                default:
                    System.out.println("Esta´en blanco"); //aparece si no hay nada más
        }
    }
}
