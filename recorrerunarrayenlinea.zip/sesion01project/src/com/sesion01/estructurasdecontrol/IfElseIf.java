package com.sesion01.estructurasdecontrol;

public class IfElseIf {

    public static void main(String[] args) {

        String dia = "Martes";

        //ejemplos comparar
        boolean resultadoCompararNum = 5 == 5;
        boolean resultado = dia.equals("Miercoles"); //chequear si es igual a algo
        System.out.println(resultado);

        //if else if

        if(dia.equals("Martes")){
            System.out.println("Mucho anímo");
        } else if (dia.equals("Lunes")){
            System.out.println("Lunes de mierda");
        } else if (dia.equals("Martes")){
            System.out.println("Peste pura");
        }
    }
}
