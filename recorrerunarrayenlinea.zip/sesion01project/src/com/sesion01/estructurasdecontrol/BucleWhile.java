package com.sesion01.estructurasdecontrol;

public class BucleWhile {

    public static void main(String[] args) {

        //bucle indeterminado

        int edad = 18;
        int contador = 0;
        boolean esmayordeedad;
        if(edad >= 18){
            esmayordeedad = false;
        } else{
            esmayordeedad = true;
        }

        while(esmayordeedad = true){
            System.out.println("si que lo es pesao");
            contador ++;
            if(contador == 5){
                break;
            }
        }
    }
}
