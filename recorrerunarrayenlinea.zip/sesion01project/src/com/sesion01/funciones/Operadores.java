package com.sesion01.funciones;

public class Operadores {

    public static void main(String[] args) {

        //aritmeticos

        int valor1 = 10;
        int valor2 = 20;

        int resultado = valor1 + valor2;

        //comparacion:
        // > mayor que
        // < menor que
        // >= mayor igual que
        // <= menor igual que

        boolean resultadooperacion = valor1 > valor2;
        System.out.println(resultadooperacion);

        //operadores logicos
        //and &&
        // or ||

        boolean resultado3 = valor1 > 5 && valor2 < 60; //es mayor que 5 y el valor2 es menor que 60? = true/false
        System.out.println(resultado3);
    }





}
