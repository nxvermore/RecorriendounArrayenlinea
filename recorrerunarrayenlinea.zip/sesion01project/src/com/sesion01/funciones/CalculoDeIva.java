package com.sesion01.funciones;

public class CalculoDeIva {

    public static void main(String[] args) {

       double precio = 25.30;

       double preciofinal = calculareliva(precio);
        System.out.println(precio + calculareliva(precio));
    }

    static double calculareliva(double precio) {
        return precio * 0.21;
    }
}
