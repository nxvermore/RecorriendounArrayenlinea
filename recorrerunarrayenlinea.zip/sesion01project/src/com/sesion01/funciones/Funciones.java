package com.sesion01.funciones;

public class Funciones {

    public static void main(String[] args) {


        //opcion 1: funcion sin parametros y sin retorno, por eso es VOID
        //es un bloque de código que podemos repetir en cualquier otro apartado de la aplicación
       // showMenu();

        //opcion 2: funcion sin parametros y con tipo de retorno
        //System.out.println(getMenu());

        //opcion 3: funcion con parametros y sin tipo de retorno
        //imprimirSaludo("Bienvenido a la web");

        //opcion 4: funcion con parametros (varios) y con tipo de retorno
        String nombre = "Adrian";
        String apellido = "Apellido";
        //=> creo las dos variables que voy a usar en la funcion
        String saludo = obtenerSaludo(nombre, apellido); //=> esto asigna los dos parametros a la funcion
        System.out.println(saludo);

        //opcion 5: funcion con sobrecargas - sirve para duplicar un metodo siempre y cuando tengan diferentes numeros o tipos de parámetros
        int valor1 = 10;
        int valor2 = 30;
        int valor3 = 40; // => para aplicar sobrecarga
        int suma = calcularresultado(valor1, valor2);
        System.out.println(calcularresultado(valor1, valor2));
    }

    private static int calcularresultado(int valor1, int valor2) {
        return valor1 * valor2;

    }

    private static int calcularresultado(int valor1, int valor2, int valor3) {
        return valor1 * valor2 + valor3; //funcion con sobrecarga añadiendo valor int

    }

    //la funcion obtiene el paramtro nombre y apellido y opera con ellos
    static String obtenerSaludo(String nombreasaludar, String apellidoasaludar) {
        return "Buenas hombre " + nombreasaludar + " " + apellidoasaludar;
    }

    static void imprimirSaludo(String textobienvenida) {
        System.out.println("Texto de entrada: " + textobienvenida); //esto es un paso por valor, lo midifico dentro de la función y no desde fuera
    }


    static void showMenu(){
        System.out.println("Bienvenidos a mi web");
        System.out.println("1 - Ver productos");
        System.out.println("2 - Comprar producto");
        System.out.println("3 - Salir de la tienda");
    }

    static String getMenu(){
        return "Texto que devuelvo"; //este es el tipo de retorno que devuelve la función
    }
}
